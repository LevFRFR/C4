package Characters;


// TODO: Auto-generated Javadoc
/**
 * The Enum Item.
 */
public enum Item {
	
	/** The poison. */
	POISON, 
 /** The potion. */
 POTION, 
 /** The coins. */
 COINS;
}
