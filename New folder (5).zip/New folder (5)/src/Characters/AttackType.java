package Characters;
// TODO: Auto-generated Javadoc
/**
 * The Enum AttackType.
 */
enum AttackType {
	
	/** The punch. */
	PUNCH, 
 /** The kick. */
 KICK;
}