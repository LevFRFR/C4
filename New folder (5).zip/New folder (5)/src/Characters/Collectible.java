package Characters;
import java.util.ArrayList;


public class Collectible {

	
	
	private ArrayList<Item> list;
	
	
	public void pickupItem(Item item) {
		list.add(item);
	}
	
	
}
